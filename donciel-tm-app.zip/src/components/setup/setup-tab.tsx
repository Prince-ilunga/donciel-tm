"use client";

import React, { useState, useMemo, useCallback, useEffect, useRef } from "react";
import { useAppStore } from "@/stores/app-store";
import { t } from "@/lib/i18n";
import { useStats, useTrades } from "@/lib/hooks";
import { useTimeFilter } from "@/lib/use-time-filter";
import { TimeFilterBar } from "@/components/shared/time-filter-bar";
import { cn, getContractSize } from "@/lib/utils";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectSeparator,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  FolderOpen,
  Database,
  UserCircle,
  BarChart3,
  Target,
  TrendingUp,
  ArrowUpRight,
  ArrowDownRight,
  Plus,
  CalendarIcon,
  Upload,
  X,
  Calculator,
  Clock,
  Eye,
  ArrowLeft,
  List,
  FileEdit,
  Filter,
  ChevronDown,
  Trash2,
  Pencil,
} from "lucide-react";
import { toast } from "sonner";
import { format } from "date-fns";

// ─── Constants ───────────────────────────────────────────────
const DEFAULT_PAIRS = ["XAUUSD", "US30", "US100", "EURUSD", "GBPUSD"];
const SESSIONS = ["LONDON", "NEW YORK", "ASIE", "OVERLAP", "MACRO CHER", "MACRO PEU CHER"];
const MARKET_CONDITIONS = ["CONTINUATION", "RETRACEMENT"];
const TIMEFRAMES_ANALYSIS = ["M15", "M30", "H1", "H4", "D1", "W1"];
const TIMEFRAMES_ENTRY = ["M1", "M5", "M15", "M30", "H1"];
const SETUPS = ["SETUP A", "SETUP A+", "SETUP B", "SETUP B+", "SETUP C"];
const STRUCTURES = ["HAUSSIÈRE", "BAISSIÈRE", "RANGE"];
const ENTRY_MODELS = ["ANGLOBANTE", "LOT À 3 BOUGIES", "MARKET SHIFT"];

// ─── Custom Setup Types ──────────────────────────────────────
interface CustomSetup {
  id: string;
  name: string;
  icon: string;
  color: string;
}

const CUSTOM_SETUPS_STORAGE_KEY = "donciel-custom-setups";
const MAX_CUSTOM_SETUPS = 6;

const DEFAULT_CUSTOM_SETUPS: CustomSetup[] = [
  { id: "custom-1", name: "SETUP PERSONNALISÉ", icon: "👤", color: "gold" },
];

const EMOJI_OPTIONS = ["👤", "🎯", "⚡", "🔥", "💎", "🌟", "🏆", "📊", "🎮", "🚀", "💰", "🎲", "📈", "🧠", "💡", "⚙️"];
const COLOR_OPTIONS = ["gold", "emerald", "violet", "rose", "cyan", "orange", "pink", "teal"];

const COLOR_MAP: Record<string, { text: string; bg: string; bgLight: string; border: string; hoverBg: string }> = {
  gold: { text: "text-gold", bg: "bg-gold/10", bgLight: "bg-gold/5", border: "border-gold/30", hoverBg: "hover:bg-gold/5" },
  emerald: { text: "text-emerald-500", bg: "bg-emerald-500/10", bgLight: "bg-emerald-500/5", border: "border-emerald-500/30", hoverBg: "hover:bg-emerald-500/5" },
  violet: { text: "text-violet-500", bg: "bg-violet-500/10", bgLight: "bg-violet-500/5", border: "border-violet-500/30", hoverBg: "hover:bg-violet-500/5" },
  rose: { text: "text-rose-500", bg: "bg-rose-500/10", bgLight: "bg-rose-500/5", border: "border-rose-500/30", hoverBg: "hover:bg-rose-500/5" },
  cyan: { text: "text-cyan-500", bg: "bg-cyan-500/10", bgLight: "bg-cyan-500/5", border: "border-cyan-500/30", hoverBg: "hover:bg-cyan-500/5" },
  orange: { text: "text-orange-500", bg: "bg-orange-500/10", bgLight: "bg-orange-500/5", border: "border-orange-500/30", hoverBg: "hover:bg-orange-500/5" },
  pink: { text: "text-pink-500", bg: "bg-pink-500/10", bgLight: "bg-pink-500/5", border: "border-pink-500/30", hoverBg: "hover:bg-pink-500/5" },
  teal: { text: "text-teal-500", bg: "bg-teal-500/10", bgLight: "bg-teal-500/5", border: "border-teal-500/30", hoverBg: "hover:bg-teal-500/5" },
};

// ─── Custom Setup Hook ───────────────────────────────────────
function loadCustomSetupsFromStorage(): CustomSetup[] {
  if (typeof window === "undefined") return DEFAULT_CUSTOM_SETUPS;
  try {
    const stored = localStorage.getItem(CUSTOM_SETUPS_STORAGE_KEY);
    if (stored) {
      const parsed = JSON.parse(stored);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    }
  } catch {
    // ignore parse errors
  }
  return DEFAULT_CUSTOM_SETUPS;
}

function useCustomSetups() {
  const [customSetups, setCustomSetups] = useState<CustomSetup[]>(loadCustomSetupsFromStorage);

  const saveSetups = useCallback((setups: CustomSetup[]) => {
    setCustomSetups(setups);
    try {
      localStorage.setItem(CUSTOM_SETUPS_STORAGE_KEY, JSON.stringify(setups));
    } catch {
      // ignore storage errors
    }
  }, []);

  const addSetup = useCallback((setup: Omit<CustomSetup, "id">) => {
    setCustomSetups(prev => {
      const maxNum = prev.reduce((max, s) => {
        const match = s.id.match(/^custom-(\d+)$/);
        return match ? Math.max(max, parseInt(match[1])) : max;
      }, 0);
      const newSetup: CustomSetup = { ...setup, id: `custom-${maxNum + 1}` };
      const updated = [...prev, newSetup];
      try {
        localStorage.setItem(CUSTOM_SETUPS_STORAGE_KEY, JSON.stringify(updated));
      } catch { /* ignore */ }
      return updated;
    });
  }, []);

  const updateSetup = useCallback((id: string, updates: Partial<Omit<CustomSetup, "id">>) => {
    setCustomSetups(prev => {
      const updated = prev.map(s => s.id === id ? { ...s, ...updates } : s);
      try {
        localStorage.setItem(CUSTOM_SETUPS_STORAGE_KEY, JSON.stringify(updated));
      } catch { /* ignore */ }
      return updated;
    });
  }, []);

  const deleteSetup = useCallback((id: string) => {
    setCustomSetups(prev => {
      const updated = prev.filter(s => s.id !== id);
      try {
        localStorage.setItem(CUSTOM_SETUPS_STORAGE_KEY, JSON.stringify(updated));
      } catch { /* ignore */ }
      return updated;
    });
  }, []);

  return { customSetups, addSetup, updateSetup, deleteSetup, saveSetups };
}

// ─── TradeFormData ───────────────────────────────────────────
interface TradeFormData {
  date: string;
  pair: string;
  customPair: string;
  direction: "LONG" | "SHORT";
  session: string;
  marketCondition: string;
  timeframeAnalysis: string;
  timeframeEntry: string;
  setup: string;
  structure: string;
  entryModel: string;
  entryPrice: string;
  stopLoss: string;
  takeProfit: string;
  exitPrice: string;
  entryTime: string;
  exitTime: string;
  lotSize: string;
  newsEnabled: boolean;
  emotions: string;
  confluence: string;
  mistakes: string;
  lessons: string;
  notes: string;
  contextFile: File | null;
  entryFile: File | null;
  exitFile: File | null;
}

const initialFormData: TradeFormData = {
  date: format(new Date(), "yyyy-MM-dd"),
  pair: "",
  customPair: "",
  direction: "LONG",
  session: "",
  marketCondition: "",
  timeframeAnalysis: "",
  timeframeEntry: "",
  setup: "",
  structure: "",
  entryModel: "",
  entryPrice: "",
  stopLoss: "",
  takeProfit: "",
  exitPrice: "",
  entryTime: "",
  exitTime: "",
  lotSize: "",
  newsEnabled: false,
  emotions: "",
  confluence: "",
  mistakes: "",
  lessons: "",
  notes: "",
  contextFile: null,
  entryFile: null,
  exitFile: null,
};

// ─── Auto-Calculator ─────────────────────────────────────────
function calculateAuto(formData: TradeFormData) {
  const entryPrice = parseFloat(formData.entryPrice);
  const stopLoss = parseFloat(formData.stopLoss);
  const takeProfit = parseFloat(formData.takeProfit);
  const exitPrice = parseFloat(formData.exitPrice);
  const lotSize = parseFloat(formData.lotSize);

  const result: {
    rr: number | null;
    pnl: number | null;
    resultLabel: "WIN" | "LOSS" | "BE" | null;
    duration: string | null;
  } = { rr: null, pnl: null, resultLabel: null, duration: null };

  if (!isNaN(entryPrice) && !isNaN(stopLoss) && !isNaN(takeProfit)) {
    const risk = Math.abs(entryPrice - stopLoss);
    const reward = Math.abs(takeProfit - entryPrice);
    if (risk > 0) {
      result.rr = parseFloat((reward / risk).toFixed(2));
    }
  }

  if (!isNaN(exitPrice) && !isNaN(entryPrice) && !isNaN(lotSize) && formData.exitPrice !== "") {
    const priceDiff = formData.direction === "LONG"
      ? exitPrice - entryPrice
      : entryPrice - exitPrice;
    const contractSize = getContractSize(formData.pair);
    result.pnl = parseFloat((priceDiff * lotSize * contractSize).toFixed(2));
  }

  if (!isNaN(exitPrice) && !isNaN(entryPrice) && !isNaN(stopLoss) && !isNaN(takeProfit) && formData.exitPrice !== "") {
    if (formData.direction === "LONG") {
      if (exitPrice >= takeProfit) result.resultLabel = "WIN";
      else if (exitPrice <= stopLoss) result.resultLabel = "LOSS";
      else result.resultLabel = "BE";
    } else {
      if (exitPrice <= takeProfit) result.resultLabel = "WIN";
      else if (exitPrice >= stopLoss) result.resultLabel = "LOSS";
      else result.resultLabel = "BE";
    }

    // Adjust RR based on result to match backend logic
    if (result.resultLabel === "LOSS") {
      result.rr = -1;
    } else if (result.resultLabel === "BE" && !isNaN(exitPrice) && formData.exitPrice !== "") {
      // Calculate partial RR for BE: actual price movement / risk
      const risk = Math.abs(entryPrice - stopLoss);
      if (risk > 0) {
        const priceDiff = formData.direction === "LONG"
          ? exitPrice - entryPrice
          : entryPrice - exitPrice;
        result.rr = parseFloat((priceDiff / risk).toFixed(2));
      }
    }
  }

  if (formData.entryTime && formData.exitTime) {
    const [eH, eM] = formData.entryTime.split(":").map(Number);
    const [xH, xM] = formData.exitTime.split(":").map(Number);
    if (!isNaN(eH) && !isNaN(eM) && !isNaN(xH) && !isNaN(xM)) {
      let totalMinutes = (xH * 60 + xM) - (eH * 60 + eM);
      if (totalMinutes < 0) totalMinutes += 24 * 60;
      const hours = Math.floor(totalMinutes / 60);
      const minutes = totalMinutes % 60;
      result.duration = hours > 0 ? `${hours}h ${minutes}min` : `${minutes}min`;
    }
  }

  return result;
}

// ─── Sub-view type helper ────────────────────────────────────
type SubView = "main" | "donciel-verification" | "donciel-saisie" | `custom-${string}-verification` | `custom-${string}-saisie`;

function isDoncielSubView(sv: SubView): boolean {
  return sv.startsWith("donciel");
}

function isCustomSubView(sv: SubView): boolean {
  return sv.startsWith("custom-") && !sv.startsWith("custom-") === false;
}

function getCustomSetupIdFromSubView(sv: SubView): string | null {
  const match = sv.match(/^custom-(.+?)-(verification|saisie)$/);
  return match ? match[1] : null;
}

// ─── Main Component ──────────────────────────────────────────
export function SetupTab() {
  const { user, language, setSelectedTradeId, setShowTradeDetail, setShowTradeForm } = useAppStore();
  const { period, setPeriod, filters } = useTimeFilter();
  const { stats, loading: statsLoading, refetch: refetchStats } = useStats(filters);
  const { trades, loading: tradesLoading, refetch: refetchTrades } = useTrades(filters);

  // Sub-view state
  const [subView, setSubView] = useState<SubView>("main");
  const [showSaisieDialog, setShowSaisieDialog] = useState(false);
  const [saisieMode, setSaisieMode] = useState<"donciel" | "custom">("donciel");
  const [saisieCustomSetupName, setSaisieCustomSetupName] = useState<string>("");

  // Custom setups
  const { customSetups, addSetup, updateSetup, deleteSetup } = useCustomSetups();

  // Setup edit/add dialog
  const [showSetupDialog, setShowSetupDialog] = useState(false);
  const [editingSetup, setEditingSetup] = useState<CustomSetup | null>(null);

  // Delete setup confirmation
  const [deleteSetupTarget, setDeleteSetupTarget] = useState<CustomSetup | null>(null);

  useEffect(() => {
    refetchStats();
    refetchTrades();
  }, [refetchStats, refetchTrades]);

  const statsData = (stats as any)?.stats ?? stats;

  // Filter trades for DONCIEL SETUP (standard setups A, A+, B, B+, C)
  const doncielTrades = useMemo(() =>
    trades.filter(trade => !trade.setup || SETUPS.includes(trade.setup)),
    [trades]
  );

  // Filter trades for a specific custom setup by name
  const getCustomSetupTrades = useCallback((setupName: string) => {
    return trades.filter(trade => trade.setup === setupName);
  }, [trades]);

  const handleTradeClick = (tradeId: string) => {
    setSelectedTradeId(tradeId);
    setShowTradeDetail(true);
  };

  const handleTradeCreated = useCallback(() => {
    refetchTrades();
    refetchStats();
  }, [refetchTrades, refetchStats]);

  const openSaisie = (mode: "donciel" | "custom", customSetupName?: string) => {
    setSaisieMode(mode);
    setSaisieCustomSetupName(customSetupName || "");
    setShowSaisieDialog(true);
  };

  // ─── Main View ────────────────────────────────────
  if (subView === "main") {
    return (
      <div className="p-4 md:p-6 space-y-6 max-w-[1600px] mx-auto overflow-x-hidden">
        {/* Header */}
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-foreground">
            {t(language, "setupTab")}
          </h2>
          <p className="text-sm text-muted-foreground mt-1">
            {t(language, "setupDescription")}
          </p>
        </div>

        {/* Setup Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
          {/* DONCIEL SETUP — always first, no edit/delete */}
          <Card
            className="p-6 cursor-pointer hover:border-primary/30 hover:bg-primary/5 transition-all duration-300 group"
            onClick={() => setSubView("donciel-verification")}
          >
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center group-hover:bg-primary/20 transition-colors">
                <Database className="w-5 h-5 text-primary" />
              </div>
              <div>
                <h3 className="text-lg font-bold">{t(language, "doncielSetup")}</h3>
                <p className="text-xs text-muted-foreground">{t(language, "baseDonnees")}</p>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <SetupStatCard label={t(language, "totalTrades")} value={doncielTrades.length} />
              <SetupStatCard label={t(language, "totalRR")} value={doncielTrades.reduce((s, t) => s + (t.rr ?? 0), 0).toFixed(2)} />
              <SetupStatCard label={t(language, "winRate")} value={`${doncielTrades.length > 0 ? ((doncielTrades.filter(t => t.result === "WIN").length / doncielTrades.filter(t => t.result).length) * 100 || 0).toFixed(1) : "0.0"}%`} />
              <SetupStatCard label={t(language, "avgRR")} value={doncielTrades.length > 0 ? (doncielTrades.reduce((s, t) => s + (t.rr ?? 0), 0) / doncielTrades.length).toFixed(2) : "0.00"} />
            </div>
          </Card>

          {/* Custom Setup Cards */}
          {customSetups.map((setup) => {
            const colors = COLOR_MAP[setup.color] || COLOR_MAP.gold;
            const setupTrades = getCustomSetupTrades(setup.name);
            return (
              <Card
                key={setup.id}
                className={cn(
                  "p-6 cursor-pointer transition-all duration-300 group relative",
                  colors.hoverBg,
                  `hover:${colors.border}`
                )}
                onClick={() => setSubView(`custom-${setup.id}-verification` as SubView)}
              >
                {/* Delete button */}
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    setDeleteSetupTarget(setup);
                  }}
                  className="absolute top-3 right-3 p-1.5 rounded-md text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-colors opacity-0 group-hover:opacity-100 z-10"
                  title={t(language, "deleteSetup")}
                >
                  <X className="w-3.5 h-3.5" />
                </button>

                {/* Edit button */}
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    setEditingSetup(setup);
                    setShowSetupDialog(true);
                  }}
                  className="absolute top-3 right-10 p-1.5 rounded-md text-muted-foreground hover:text-primary hover:bg-primary/10 transition-colors opacity-0 group-hover:opacity-100 z-10"
                  title={t(language, "editSetup")}
                >
                  <Pencil className="w-3.5 h-3.5" />
                </button>

                <div className="flex items-center gap-3 mb-4">
                  <div className={cn("w-10 h-10 rounded-xl flex items-center justify-center group-hover:opacity-80 transition-colors text-xl", colors.bg)}>
                    {setup.icon}
                  </div>
                  <div>
                    <h3 className={cn("text-lg font-bold", colors.text)}>{setup.name}</h3>
                    <p className="text-xs text-muted-foreground">{t(language, "baseDonnees")}</p>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <SetupStatCard label={t(language, "totalTrades")} value={setupTrades.length} />
                  <SetupStatCard label={t(language, "totalRR")} value={setupTrades.reduce((s, t) => s + (t.rr ?? 0), 0).toFixed(2)} />
                  <SetupStatCard label={t(language, "winRate")} value={`${setupTrades.length > 0 ? ((setupTrades.filter(t => t.result === "WIN").length / setupTrades.filter(t => t.result).length) * 100 || 0).toFixed(1) : "0.0"}%`} />
                  <SetupStatCard label={t(language, "avgRR")} value={setupTrades.length > 0 ? (setupTrades.reduce((s, t) => s + (t.rr ?? 0), 0) / setupTrades.length).toFixed(2) : "0.00"} />
                </div>
              </Card>
            );
          })}

          {/* Add Setup Card */}
          {customSetups.length < MAX_CUSTOM_SETUPS && (
            <Card
              className="p-6 cursor-pointer border-dashed border-2 hover:border-primary/30 hover:bg-primary/5 transition-all duration-300 group"
              onClick={() => {
                if (customSetups.length >= MAX_CUSTOM_SETUPS) {
                  toast.error(t(language, "maxSetupsReached"));
                  return;
                }
                setEditingSetup(null);
                setShowSetupDialog(true);
              }}
            >
              <div className="flex flex-col items-center justify-center py-6 gap-3">
                <div className="w-12 h-12 rounded-xl bg-muted/30 flex items-center justify-center group-hover:bg-primary/10 transition-colors">
                  <Plus className="w-6 h-6 text-muted-foreground group-hover:text-primary transition-colors" />
                </div>
                <div className="text-center">
                  <h3 className="text-sm font-semibold text-muted-foreground group-hover:text-foreground transition-colors">
                    {t(language, "addSetup")}
                  </h3>
                </div>
              </div>
            </Card>
          )}
        </div>

        {/* Setup Edit/Add Dialog */}
        <SetupEditDialog
          open={showSetupDialog}
          onOpenChange={setShowSetupDialog}
          language={language}
          editingSetup={editingSetup}
          onSave={(data) => {
            if (editingSetup) {
              updateSetup(editingSetup.id, data);
            } else {
              addSetup(data);
            }
          }}
        />

        {/* Delete Setup Confirmation Dialog */}
        <Dialog open={!!deleteSetupTarget} onOpenChange={(open) => { if (!open) setDeleteSetupTarget(null); }}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Trash2 className="w-5 h-5 text-destructive" />
                {t(language, "deleteSetup")}
              </DialogTitle>
              <DialogDescription>
                {t(language, "deleteSetupConfirm")}
              </DialogDescription>
            </DialogHeader>
            <DialogFooter className="gap-2 sm:gap-0">
              <Button variant="outline" onClick={() => setDeleteSetupTarget(null)}>
                {t(language, "cancel")}
              </Button>
              <Button
                variant="destructive"
                onClick={() => {
                  if (deleteSetupTarget) {
                    deleteSetup(deleteSetupTarget.id);
                    setDeleteSetupTarget(null);
                    toast.success(language === "fr" ? "Setup supprimé" : "Setup deleted");
                  }
                }}
              >
                {t(language, "delete")}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    );
  }

  // ─── Sub-views ──────────────────────────────────────
  const isDonciel = isDoncielSubView(subView);
  const customSetupId = getCustomSetupIdFromSubView(subView);
  const customSetup = customSetupId ? customSetups.find(s => s.id === customSetupId) : null;

  const currentTrades = isDonciel
    ? doncielTrades
    : customSetup
      ? getCustomSetupTrades(customSetup.name)
      : [];

  const title = isDonciel
    ? t(language, "doncielSetup")
    : customSetup
      ? customSetup.name
      : t(language, "setupPersonnalise");

  const setupPrefix = isDonciel ? "donciel" : `custom-${customSetupId}`;

  return (
    <div className="p-4 md:p-6 space-y-6 max-w-[1600px] mx-auto overflow-x-hidden">
      {/* Header with back button */}
      <div className="flex items-center gap-2 md:gap-3 min-w-0">
        <Button variant="ghost" size="sm" onClick={() => setSubView("main")} className="gap-1 shrink-0">
          <ArrowLeft className="w-4 h-4" />
          {t(language, "back")}
        </Button>
        <div className="min-w-0">
          <h2 className="text-lg md:text-xl font-bold truncate">{title}</h2>
        </div>
      </div>

      {/* Sub-navigation buttons */}
      <div className="flex flex-wrap gap-2">
        <Button
          variant={subView.endsWith("verification") ? "default" : "outline"}
          size="sm"
          className="gap-1 sm:gap-2 text-[10px] sm:text-xs"
          onClick={() => setSubView(`${setupPrefix}-verification` as SubView)}
        >
          <List className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
          <span className="truncate">{t(language, "doncielSetupVerification")}</span>
        </Button>
        <Button
          variant={subView.endsWith("saisie") ? "default" : "outline"}
          size="sm"
          className="gap-1 sm:gap-2 text-[10px] sm:text-xs"
          onClick={() => openSaisie(isDonciel ? "donciel" : "custom", customSetup?.name)}
        >
          <FileEdit className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
          <span className="truncate">{t(language, "saisieDesTrades")}</span>
        </Button>
      </div>

      {/* Time Filter */}
      <TimeFilterBar language={language} period={period} onPeriodChange={setPeriod} />

      {/* Verification View - Trade List */}
      <TradeVerificationList
        trades={currentTrades}
        language={language}
        isAdmin={user?.role === "admin"}
        onTradeClick={handleTradeClick}
        onTradeDeleted={handleTradeCreated}
        loading={tradesLoading}
      />

      {/* Trade Form Dialog (Saisie) */}
      <TradeFormDialog
        open={showSaisieDialog}
        onOpenChange={setShowSaisieDialog}
        language={language}
        onTradeCreated={handleTradeCreated}
        setupMode={saisieMode}
        customSetupName={saisieCustomSetupName}
      />
    </div>
  );
}

// ─── Sub-Components ──────────────────────────────────────────

function SetupStatCard({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="rounded-lg bg-muted/30 p-3">
      <div className="text-[9px] uppercase tracking-wider text-muted-foreground mb-1">{label}</div>
      <div className="text-lg font-bold font-mono">{value}</div>
    </div>
  );
}

// ─── Setup Edit/Add Dialog ───────────────────────────────────
function SetupEditDialog({
  open,
  onOpenChange,
  language,
  editingSetup,
  onSave,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  language: "fr" | "en";
  editingSetup: CustomSetup | null;
  onSave: (data: { name: string; icon: string; color: string }) => void;
}) {
  const [dialogKey, setDialogKey] = useState(0);
  const [name, setName] = useState("");
  const [icon, setIcon] = useState("👤");
  const [color, setColor] = useState("gold");

  // Reset form when dialog opens
  const handleOpenChange = (isOpen: boolean) => {
    if (isOpen) {
      if (editingSetup) {
        setName(editingSetup.name);
        setIcon(editingSetup.icon);
        setColor(editingSetup.color);
      } else {
        setName("");
        setIcon("👤");
        setColor("gold");
      }
      setDialogKey(prev => prev + 1);
    }
    onOpenChange(isOpen);
  };

  const handleSave = () => {
    if (!name.trim()) {
      toast.error(language === "fr" ? "Le nom est requis" : "Name is required");
      return;
    }
    onSave({ name: name.trim(), icon, color });
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="sm:max-w-md" key={dialogKey}>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            {editingSetup ? <Pencil className="w-5 h-5" /> : <Plus className="w-5 h-5" />}
            {editingSetup ? t(language, "editSetup") : t(language, "addSetup")}
          </DialogTitle>
          <DialogDescription className="sr-only">
            {editingSetup ? t(language, "editSetup") : t(language, "addSetup")}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-5 py-2">
          {/* Name */}
          <div className="space-y-1.5">
            <Label className="text-xs font-medium">{t(language, "setupName")}</Label>
            <Input
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder={language === "fr" ? "Mon Setup" : "My Setup"}
              className="h-9"
            />
          </div>

          {/* Icon */}
          <div className="space-y-2">
            <Label className="text-xs font-medium">{t(language, "setupIcon")}</Label>
            <div className="grid grid-cols-8 gap-2">
              {EMOJI_OPTIONS.map((emoji) => (
                <button
                  key={emoji}
                  type="button"
                  onClick={() => setIcon(emoji)}
                  className={cn(
                    "w-10 h-10 rounded-lg flex items-center justify-center text-lg transition-all",
                    icon === emoji
                      ? "bg-primary/15 ring-2 ring-primary scale-110"
                      : "bg-muted/30 hover:bg-muted/60"
                  )}
                >
                  {emoji}
                </button>
              ))}
            </div>
          </div>

          {/* Color */}
          <div className="space-y-2">
            <Label className="text-xs font-medium">{t(language, "setupColor")}</Label>
            <div className="grid grid-cols-4 gap-2">
              {COLOR_OPTIONS.map((c) => {
                const colors = COLOR_MAP[c];
                const isSelected = color === c;
                return (
                  <button
                    key={c}
                    type="button"
                    onClick={() => setColor(c)}
                    className={cn(
                      "flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-all",
                      isSelected
                        ? cn(colors.bg, colors.text, "ring-2 ring-current scale-105")
                        : "bg-muted/30 text-muted-foreground hover:bg-muted/60"
                    )}
                  >
                    <span className={cn("w-3 h-3 rounded-full", colors.bg, "ring-1 ring-current/20")} />
                    <span className="capitalize">{c}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Preview */}
          <div className="rounded-xl border border-border bg-muted/10 p-4">
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-2">
              {language === "fr" ? "Aperçu" : "Preview"}
            </div>
            <div className="flex items-center gap-3">
              <div className={cn("w-10 h-10 rounded-xl flex items-center justify-center text-xl", (COLOR_MAP[color] || COLOR_MAP.gold).bg)}>
                {icon}
              </div>
              <div>
                <h3 className={cn("text-lg font-bold", (COLOR_MAP[color] || COLOR_MAP.gold).text)}>
                  {name || (language === "fr" ? "Nouveau Setup" : "New Setup")}
                </h3>
                <p className="text-xs text-muted-foreground">{t(language, "baseDonnees")}</p>
              </div>
            </div>
          </div>
        </div>

        <DialogFooter className="gap-2 sm:gap-0">
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            {t(language, "cancel")}
          </Button>
          <Button onClick={handleSave} className="gap-2">
            {editingSetup ? t(language, "edit") : t(language, "save")}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ─── Trade Verification List ─────────────────────────────────
function TradeVerificationList({
  trades,
  language,
  isAdmin,
  onTradeClick,
  onTradeDeleted,
  loading,
}: {
  trades: any[];
  language: "fr" | "en";
  isAdmin: boolean;
  onTradeClick: (id: string) => void;
  onTradeDeleted: () => void;
  loading: boolean;
}) {
  const [filters, setFilters] = useState({
    condition: "",
    setup: "",
    entryModel: "",
    structure: "",
    timing: "",
  });
  const [showFilters, setShowFilters] = useState(false);

  // Delete confirmation state
  const [deleteTarget, setDeleteTarget] = useState<{ id: string; pair: string; direction: string } | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  const handleDeleteTrade = useCallback(async () => {
    if (!deleteTarget || isDeleting) return;
    setIsDeleting(true);
    try {
      const res = await fetch(`/api/trades/${deleteTarget.id}`, { method: "DELETE" });
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || "Delete failed");
      }
      toast.success(language === "fr" ? "Trade supprimé !" : "Trade deleted!");
      setDeleteTarget(null);
      onTradeDeleted();
    } catch (error: any) {
      toast.error(error.message || (language === "fr" ? "Erreur lors de la suppression" : "Delete failed"));
    } finally {
      setIsDeleting(false);
    }
  }, [deleteTarget, isDeleting, language, onTradeDeleted]);

  // Stats
  const longCount = trades.filter(t => t.direction === "LONG").length;
  const shortCount = trades.filter(t => t.direction === "SHORT").length;
  const totalRR = trades.reduce((s, t) => s + (t.rr ?? 0), 0);

  // Apply filters
  const { condition, setup, entryModel, structure, timing } = filters;
  const filteredTrades = useMemo(() => {
    return trades.filter(trade => {
      if (condition && trade.marketCondition !== condition) return false;
      if (setup && trade.setup !== setup) return false;
      if (entryModel && trade.entryModel !== entryModel) return false;
      if (structure && trade.structure !== structure) return false;
      if (timing && trade.session !== timing) return false;
      return true;
    });
  }, [trades, condition, setup, entryModel, structure, timing]);

  return (
    <div className="space-y-4">
      {/* Stats bar */}
      <Card className="p-4">
        <div className="flex flex-wrap items-center gap-4">
          <div className="flex items-center gap-2">
            <BarChart3 className="w-4 h-4 text-muted-foreground" />
            <span className="text-sm font-medium">{filteredTrades.length} trades</span>
          </div>
          <Badge variant="outline" className="text-xs font-mono">
            RR Total: {totalRR.toFixed(2)}
          </Badge>
          <div className="flex items-center gap-1.5">
            <Badge className="text-[10px] bg-profit/15 text-profit border-profit/20">
              <ArrowUpRight className="w-3 h-3 mr-0.5" /> {longCount}
            </Badge>
            <Badge className="text-[10px] bg-loss/15 text-loss border-loss/20">
              <ArrowDownRight className="w-3 h-3 mr-0.5" /> {shortCount}
            </Badge>
          </div>

          <Button
            variant="ghost"
            size="sm"
            className="ml-auto gap-1"
            onClick={() => setShowFilters(!showFilters)}
          >
            <Filter className="w-3.5 h-3.5" />
            {t(language, "filtres")}
            <ChevronDown className={cn("w-3 h-3 transition-transform", showFilters && "rotate-180")} />
          </Button>
        </div>

        {/* Filters */}
        {showFilters && (
          <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mt-4 pt-4 border-t border-border">
            <Select value={filters.condition} onValueChange={v => setFilters(p => ({ ...p, condition: v === "__all__" ? "" : v }))}>
              <SelectTrigger className="h-8 text-xs"><SelectValue placeholder={t(language, "condition")} /></SelectTrigger>
              <SelectContent>
                <SelectItem value="__all__">{language === "fr" ? "Toutes" : "All"}</SelectItem>
                {MARKET_CONDITIONS.map(mc => <SelectItem key={mc} value={mc}>{mc}</SelectItem>)}
              </SelectContent>
            </Select>
            <Select value={filters.setup} onValueChange={v => setFilters(p => ({ ...p, setup: v === "__all__" ? "" : v }))}>
              <SelectTrigger className="h-8 text-xs"><SelectValue placeholder={t(language, "setup")} /></SelectTrigger>
              <SelectContent>
                <SelectItem value="__all__">{language === "fr" ? "Tous" : "All"}</SelectItem>
                {SETUPS.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
              </SelectContent>
            </Select>
            <Select value={filters.entryModel} onValueChange={v => setFilters(p => ({ ...p, entryModel: v === "__all__" ? "" : v }))}>
              <SelectTrigger className="h-8 text-xs"><SelectValue placeholder={t(language, "modelEntree")} /></SelectTrigger>
              <SelectContent>
                <SelectItem value="__all__">{language === "fr" ? "Tous" : "All"}</SelectItem>
                {ENTRY_MODELS.map(em => <SelectItem key={em} value={em}>{em}</SelectItem>)}
              </SelectContent>
            </Select>
            <Select value={filters.structure} onValueChange={v => setFilters(p => ({ ...p, structure: v === "__all__" ? "" : v }))}>
              <SelectTrigger className="h-8 text-xs"><SelectValue placeholder={t(language, "structure")} /></SelectTrigger>
              <SelectContent>
                <SelectItem value="__all__">{language === "fr" ? "Toutes" : "All"}</SelectItem>
                {STRUCTURES.map(st => <SelectItem key={st} value={st}>{t(language, st.toLowerCase().replace(/è/g, "e").replace(/é/g, "e") as any) || st}</SelectItem>)}
              </SelectContent>
            </Select>
            <Select value={filters.timing} onValueChange={v => setFilters(p => ({ ...p, timing: v === "__all__" ? "" : v }))}>
              <SelectTrigger className="h-8 text-xs"><SelectValue placeholder={t(language, "timing")} /></SelectTrigger>
              <SelectContent>
                <SelectItem value="__all__">{language === "fr" ? "Tous" : "All"}</SelectItem>
                {SESSIONS.map(s => <SelectItem key={s} value={s}>{t(language, s.toLowerCase().replace(/\s+/g, "") as any) || s}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
        )}
      </Card>

      {/* Trade list */}
      <Card className="overflow-hidden">
        {loading ? (
          <div className="p-6 space-y-3">
            {Array.from({ length: 5 }).map((_, i) => (
              <Skeleton key={i} className="h-12 w-full" />
            ))}
          </div>
        ) : filteredTrades.length === 0 ? (
          <div className="p-12 text-center">
            <BarChart3 className="w-12 h-12 mx-auto text-muted-foreground/30 mb-4" />
            <p className="text-muted-foreground">{t(language, "noData")}</p>
          </div>
        ) : (
          <>
            {/* Desktop Table */}
            <div className="hidden md:block">
              <Table>
                <TableHeader>
                  <TableRow className="hover:bg-transparent">
                    <TableHead className="text-xs font-semibold uppercase tracking-wider w-12">N°</TableHead>
                    <TableHead className="text-xs font-semibold uppercase tracking-wider">{language === "fr" ? "Long/Short" : "Long/Short"}</TableHead>
                    <TableHead className="text-xs font-semibold uppercase tracking-wider">{t(language, "date")}</TableHead>
                    <TableHead className="text-xs font-semibold uppercase tracking-wider">{t(language, "setup")}</TableHead>
                    <TableHead className="text-xs font-semibold uppercase tracking-wider text-right">RR</TableHead>
                    {isAdmin && <TableHead className="text-xs font-semibold uppercase tracking-wider w-12"></TableHead>}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredTrades.map((trade, idx) => (
                    <TableRow
                      key={trade.id}
                      className="cursor-pointer hover:bg-muted/50 transition-colors"
                      onClick={() => onTradeClick(trade.id)}
                    >
                      <TableCell className="text-sm font-mono text-muted-foreground">{idx + 1}</TableCell>
                      <TableCell>
                        <span className={cn(
                          "inline-flex items-center gap-1 text-xs font-semibold",
                          trade.direction === "LONG" ? "text-profit" : "text-loss"
                        )}>
                          {trade.direction === "LONG" ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
                          {trade.direction}
                        </span>
                      </TableCell>
                      <TableCell className="text-sm">
                        {trade.date ? format(new Date(trade.date), "dd/MM/yyyy") : "—"}
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className="text-xs font-mono">
                          {trade.setup || "—"}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <span className={cn(
                          "font-mono text-sm font-bold",
                          trade.rr !== null && trade.rr >= 0 ? "text-profit" : "text-loss"
                        )}>
                          {trade.rr !== null ? (trade.rr >= 0 ? "+" : "") + trade.rr.toFixed(2) : "—"}
                        </span>
                      </TableCell>
                      {isAdmin && (
                        <TableCell>
                          <button
                            onClick={(e) => { e.stopPropagation(); setDeleteTarget({ id: trade.id, pair: trade.pair, direction: trade.direction }); }}
                            className="p-1 rounded-md text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-colors"
                            title={language === "fr" ? "Supprimer ce trade" : "Delete this trade"}
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </TableCell>
                      )}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>

            {/* Mobile Cards */}
            <div className="md:hidden divide-y divide-border">
              {filteredTrades.map((trade, idx) => (
                <div
                  key={trade.id}
                  className="w-full p-4 flex items-center justify-between hover:bg-muted/50 transition-colors text-left"
                >
                  <button
                    onClick={() => onTradeClick(trade.id)}
                    className="flex items-center gap-3 min-w-0 flex-1"
                  >
                    <span className="text-xs font-mono text-muted-foreground w-6">{idx + 1}</span>
                    <div className={cn(
                      "w-7 h-7 rounded-full flex items-center justify-center shrink-0",
                      trade.direction === "LONG" ? "bg-profit/10 text-profit" : "bg-loss/10 text-loss"
                    )}>
                      {trade.direction === "LONG" ? <ArrowUpRight className="w-3.5 h-3.5" /> : <ArrowDownRight className="w-3.5 h-3.5" />}
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-semibold text-sm">{trade.pair}</span>
                        <Badge variant="outline" className="text-[10px] font-mono px-1">
                          {trade.setup || "—"}
                        </Badge>
                      </div>
                      <div className="text-xs text-muted-foreground mt-0.5">
                        {trade.date ? format(new Date(trade.date), "dd/MM") : "—"}
                      </div>
                    </div>
                  </button>
                  <div className="flex items-center gap-2 shrink-0 ml-3">
                    <span className={cn(
                      "font-mono text-sm font-bold",
                      trade.rr !== null && trade.rr >= 0 ? "text-profit" : "text-loss"
                    )}>
                      {trade.rr !== null ? (trade.rr >= 0 ? "+" : "") + trade.rr.toFixed(2) : "—"}
                    </span>
                    {isAdmin && (
                      <button
                        onClick={() => setDeleteTarget({ id: trade.id, pair: trade.pair, direction: trade.direction })}
                        className="p-1.5 rounded-md text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-colors"
                        title={language === "fr" ? "Supprimer ce trade" : "Delete this trade"}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </>
        )}
      </Card>

      {/* Delete Confirmation Dialog */}
      <Dialog open={!!deleteTarget} onOpenChange={(open) => { if (!open) setDeleteTarget(null); }}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Trash2 className="w-5 h-5 text-destructive" />
              {language === "fr" ? "Supprimer ce trade ?" : "Delete this trade?"}
            </DialogTitle>
            <DialogDescription>
              {deleteTarget && (
                language === "fr"
                  ? `Voulez-vous supprimer le trade ${deleteTarget.direction} ${deleteTarget.pair} ? Cette action est irréversible.`
                  : `Delete the ${deleteTarget.direction} ${deleteTarget.pair} trade? This action cannot be undone.`
              )}
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="gap-2 sm:gap-0">
            <Button variant="outline" onClick={() => setDeleteTarget(null)}>
              {language === "fr" ? "Annuler" : "Cancel"}
            </Button>
            <Button variant="destructive" onClick={handleDeleteTrade} disabled={isDeleting}>
              {isDeleting
                ? (language === "fr" ? "Suppression..." : "Deleting...")
                : (language === "fr" ? "Supprimer" : "Delete")
              }
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// ─── Result Badge ────────────────────────────────────────────
function ResultBadge({ result, language, size = "default" }: { result: string | null; language: "fr" | "en"; size?: "default" | "sm" }) {
  if (!result) return <span className="text-muted-foreground text-xs">—</span>;
  const sizeClass = size === "sm" ? "text-[10px] px-1.5 py-0" : "text-xs";
  if (result === "WIN") return <Badge className={cn("bg-profit/15 text-profit border-profit/20", sizeClass)}>{t(language, "win")}</Badge>;
  if (result === "LOSS") return <Badge className={cn("bg-loss/15 text-loss border-loss/20", sizeClass)}>{t(language, "loss")}</Badge>;
  return <Badge className={cn("bg-gold/15 text-gold border-gold/20", sizeClass)}>{t(language, "be")}</Badge>;
}

// ─── Trade Form Dialog ───────────────────────────────────────
function TradeFormDialog({
  open,
  onOpenChange,
  language,
  onTradeCreated,
  setupMode,
  customSetupName,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  language: "fr" | "en";
  onTradeCreated: () => void;
  setupMode: "donciel" | "custom";
  customSetupName?: string;
}) {
  const [formData, setFormData] = useState<TradeFormData>(initialFormData);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showCustomPair, setShowCustomPair] = useState(false);
  const [dateOpen, setDateOpen] = useState(false);
  const contextRef = useRef<HTMLInputElement>(null);
  const entryFileRef = useRef<HTMLInputElement>(null);
  const exitFileRef = useRef<HTMLInputElement>(null);

  const autoCalc = useMemo(() => calculateAuto(formData), [formData]);

  useEffect(() => {
    if (open) {
      setFormData({ ...initialFormData, date: format(new Date(), "yyyy-MM-dd") });
      setShowCustomPair(false);
    }
  }, [open]);

  const updateField = useCallback(<K extends keyof TradeFormData>(key: K, value: TradeFormData[K]) => {
    setFormData((prev) => ({ ...prev, [key]: value }));
  }, []);

  const handlePairChange = useCallback((value: string) => {
    if (value === "__custom__") { setShowCustomPair(true); updateField("pair", ""); }
    else { setShowCustomPair(false); updateField("pair", value); }
  }, [updateField]);

  const handleSubmit = async () => {
    if (!formData.date || !formData.pair || !formData.direction || !formData.session ||
        !formData.marketCondition || !formData.timeframeAnalysis || !formData.timeframeEntry ||
        !formData.entryPrice || !formData.stopLoss || !formData.takeProfit) {
      toast.error(language === "fr" ? "Remplissez les champs obligatoires" : "Fill required fields");
      return;
    }

    setIsSubmitting(true);
    try {
      const pair = showCustomPair ? formData.customPair.toUpperCase() : formData.pair;
      const exitPrice = formData.exitPrice !== "" ? parseFloat(formData.exitPrice) : null;
      const lotSize = formData.lotSize !== "" ? parseFloat(formData.lotSize) : null;

      // For custom setup mode, use the custom setup name as the trade's setup field
      const setupValue = setupMode === "custom" && customSetupName
        ? customSetupName
        : (formData.setup || null);

      const tradeData: Record<string, unknown> = {
        date: formData.date,
        pair,
        direction: formData.direction,
        session: formData.session,
        marketCondition: formData.marketCondition,
        timeframe: `${formData.timeframeAnalysis}/${formData.timeframeEntry}`,
        setup: setupValue,
        structure: formData.structure || null,
        entryModel: formData.entryModel || null,
        entryPrice: parseFloat(formData.entryPrice),
        stopLoss: parseFloat(formData.stopLoss),
        takeProfit: parseFloat(formData.takeProfit),
        exitPrice,
        entryTime: formData.entryTime || null,
        exitTime: formData.exitTime || null,
        duration: autoCalc.duration || null,
        lotSize,
        rr: autoCalc.rr,
        pnl: autoCalc.pnl,
        result: autoCalc.resultLabel,
        newsEnabled: formData.newsEnabled,
        emotions: formData.emotions || null,
        confluence: formData.confluence || null,
        mistakes: formData.mistakes || null,
        lessons: formData.lessons || null,
        notes: formData.notes || null,
      };

      const res = await fetch("/api/trades", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(tradeData),
      });

      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || "Error creating trade");
      }

      const { trade } = await res.json();

      // Upload screenshots
      const uploadPromises: Promise<void>[] = [];
      const files: { file: File | null; type: string }[] = [
        { file: formData.contextFile, type: "context" },
        { file: formData.entryFile, type: "entry" },
        { file: formData.exitFile, type: "exit" },
      ];
      for (const { file, type } of files) {
        if (file && trade?.id) {
          uploadPromises.push((async () => {
            const fd = new FormData();
            fd.append("file", file);
            fd.append("tradeId", trade.id);
            fd.append("type", type);
            const uploadRes = await fetch("/api/upload", { method: "POST", body: fd });
            if (!uploadRes.ok) {
              console.error(`Failed to upload ${type} screenshot`);
              toast.warning(language === "fr" ? `Capture "${type}" non sauvegardée` : `"${type}" screenshot not saved`);
            }
          })());
        }
      }
      await Promise.all(uploadPromises);

      toast.success(language === "fr" ? "Trade ajouté avec succès !" : "Trade added successfully!");
      onOpenChange(false);
      onTradeCreated();
    } catch (error: any) {
      toast.error(error.message || (language === "fr" ? "Erreur lors de la création" : "Error creating trade"));
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] p-0 gap-0 overflow-hidden flex flex-col">
        <div className="p-6 border-b border-border shrink-0">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-xl">
              <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
                <Plus className="w-4 h-4 text-primary" />
              </div>
              {t(language, "saisieDesTrades")}
            </DialogTitle>
            <DialogDescription className="text-sm text-muted-foreground">
              {language === "fr" ? "Remplissez les détails de votre trade" : "Fill in your trade details"}
            </DialogDescription>
          </DialogHeader>
        </div>

        <div className="flex-1 min-h-0 overflow-y-auto">
          <div className="p-6 space-y-6">
            {/* Auto-calculator display */}
            {(autoCalc.rr !== null || autoCalc.pnl !== null || autoCalc.resultLabel !== null) && (
              <div className="rounded-xl border border-primary/20 bg-primary/5 p-4 space-y-3">
                <div className="flex items-center gap-2 text-sm font-semibold text-primary">
                  <Calculator className="w-4 h-4" />
                  {language === "fr" ? "Calculs Automatiques" : "Auto-Calculated"}
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  {autoCalc.rr !== null && (
                    <div className="text-center p-2 rounded-lg bg-background/50">
                      <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1">RR</div>
                      <div className={cn("text-lg font-bold font-mono", autoCalc.rr >= 1 ? "text-profit" : "text-loss")}>{autoCalc.rr.toFixed(2)}</div>
                    </div>
                  )}
                  {autoCalc.pnl !== null && (
                    <div className="text-center p-2 rounded-lg bg-background/50">
                      <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1">P&L</div>
                      <div className={cn("text-lg font-bold font-mono", autoCalc.pnl > 0 ? "text-profit" : autoCalc.pnl < 0 ? "text-loss" : "text-gold")}>{autoCalc.pnl >= 0 ? "+" : ""}{autoCalc.pnl.toFixed(2)}</div>
                    </div>
                  )}
                  {autoCalc.resultLabel && (
                    <div className="text-center p-2 rounded-lg bg-background/50">
                      <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1">{t(language, "result")}</div>
                      <ResultBadge result={autoCalc.resultLabel} language={language} />
                    </div>
                  )}
                  {autoCalc.duration && (
                    <div className="text-center p-2 rounded-lg bg-background/50">
                      <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1"><Clock className="w-3 h-3 inline mr-0.5" />{t(language, "duration")}</div>
                      <div className="text-sm font-semibold font-mono">{autoCalc.duration}</div>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* ─── Trade Info ──────────────── */}
            <div className="space-y-4">
              <h4 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">
                {language === "fr" ? "Informations du Trade" : "Trade Information"}
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Date */}
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium">{t(language, "date")} *</Label>
                  <Popover open={dateOpen} onOpenChange={setDateOpen}>
                    <PopoverTrigger asChild>
                      <Button variant="outline" className={cn("w-full justify-start text-left font-normal h-9", !formData.date && "text-muted-foreground")}>
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {formData.date ? format(new Date(formData.date), "dd/MM/yyyy") : language === "fr" ? "Sélectionner" : "Select"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar mode="single" selected={formData.date ? new Date(formData.date) : undefined} onSelect={(date) => { if (date) { updateField("date", format(date, "yyyy-MM-dd")); setDateOpen(false); } }} initialFocus />
                    </PopoverContent>
                  </Popover>
                </div>
                {/* Pair */}
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium">{t(language, "pair")} *</Label>
                  {!showCustomPair ? (
                    <Select value={formData.pair} onValueChange={handlePairChange}>
                      <SelectTrigger className="w-full h-9"><SelectValue placeholder={language === "fr" ? "Sélectionner" : "Select"} /></SelectTrigger>
                      <SelectContent>
                        {DEFAULT_PAIRS.map(p => <SelectItem key={p} value={p}><span className="font-mono">{p}</span></SelectItem>)}
                        <SelectSeparator />
                        <SelectItem value="__custom__"><span className="text-primary text-xs">{t(language, "customPair")}</span></SelectItem>
                      </SelectContent>
                    </Select>
                  ) : (
                    <div className="flex gap-2">
                      <Input placeholder="EURJPY" value={formData.customPair} onChange={(e) => updateField("customPair", e.target.value.toUpperCase())} className="h-9 font-mono" />
                      <Button variant="ghost" size="sm" onClick={() => { setShowCustomPair(false); updateField("customPair", ""); }} className="shrink-0 h-9 px-2"><X className="w-4 h-4" /></Button>
                    </div>
                  )}
                </div>
                {/* Direction */}
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium">{t(language, "direction")} *</Label>
                  <ToggleGroup type="single" value={formData.direction} onValueChange={(val) => { if (val) updateField("direction", val as "LONG" | "SHORT"); }} className="w-full">
                    <ToggleGroupItem value="LONG" className="flex-1 data-[state=on]:bg-profit/15 data-[state=on]:text-profit h-9 text-sm font-semibold gap-1"><ArrowUpRight className="w-3.5 h-3.5" />{t(language, "long")}</ToggleGroupItem>
                    <ToggleGroupItem value="SHORT" className="flex-1 data-[state=on]:bg-loss/15 data-[state=on]:text-loss h-9 text-sm font-semibold gap-1"><ArrowDownRight className="w-3.5 h-3.5" />{t(language, "short")}</ToggleGroupItem>
                  </ToggleGroup>
                </div>
                {/* Session */}
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium">{t(language, "session")} *</Label>
                  <Select value={formData.session} onValueChange={(v) => updateField("session", v)}>
                    <SelectTrigger className="w-full h-9"><SelectValue placeholder={language === "fr" ? "Sélectionner" : "Select"} /></SelectTrigger>
                    <SelectContent>
                      {SESSIONS.map(s => <SelectItem key={s} value={s}>{t(language, s.toLowerCase().replace(/\s+/g, "") as any) || s}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                {/* Market Condition */}
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium">{t(language, "marketCondition")} *</Label>
                  <Select value={formData.marketCondition} onValueChange={(v) => updateField("marketCondition", v)}>
                    <SelectTrigger className="w-full h-9"><SelectValue placeholder={language === "fr" ? "Sélectionner" : "Select"} /></SelectTrigger>
                    <SelectContent>
                      {MARKET_CONDITIONS.map(mc => <SelectItem key={mc} value={mc}>{t(language, mc.toLowerCase() as any) || mc}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                {/* TF Analysis */}
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium">{language === "fr" ? "TF Analyse" : "Analysis TF"} *</Label>
                  <Select value={formData.timeframeAnalysis} onValueChange={(v) => updateField("timeframeAnalysis", v)}>
                    <SelectTrigger className="w-full h-9"><SelectValue placeholder={language === "fr" ? "Sélectionner" : "Select"} /></SelectTrigger>
                    <SelectContent>
                      {TIMEFRAMES_ANALYSIS.map(tf => <SelectItem key={tf} value={tf}><span className="font-mono">{tf}</span></SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                {/* TF Entry */}
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium">{language === "fr" ? "TF Entrée" : "Entry TF"} *</Label>
                  <Select value={formData.timeframeEntry} onValueChange={(v) => updateField("timeframeEntry", v)}>
                    <SelectTrigger className="w-full h-9"><SelectValue placeholder={language === "fr" ? "Sélectionner" : "Select"} /></SelectTrigger>
                    <SelectContent>
                      {TIMEFRAMES_ENTRY.map(tf => <SelectItem key={tf} value={tf}><span className="font-mono">{tf}</span></SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                {/* Setup - show DONCIEL setups for donciel mode, hidden for custom mode (auto-set) */}
                {setupMode === "donciel" && (
                  <div className="space-y-1.5">
                    <Label className="text-xs font-medium">{t(language, "setup")}</Label>
                    <Select value={formData.setup} onValueChange={(v) => updateField("setup", v)}>
                      <SelectTrigger className="w-full h-9"><SelectValue placeholder={language === "fr" ? "Sélectionner" : "Select"} /></SelectTrigger>
                      <SelectContent>
                        {SETUPS.map(s => <SelectItem key={s} value={s}><span className="font-mono font-semibold">{s}</span></SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                )}
                {setupMode === "custom" && customSetupName && (
                  <div className="space-y-1.5">
                    <Label className="text-xs font-medium">{t(language, "setup")}</Label>
                    <Input value={customSetupName} disabled className="h-9 font-mono" />
                  </div>
                )}
                {/* Structure */}
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium">{t(language, "structureField")}</Label>
                  <Select value={formData.structure} onValueChange={(v) => updateField("structure", v)}>
                    <SelectTrigger className="w-full h-9"><SelectValue placeholder={language === "fr" ? "Sélectionner" : "Select"} /></SelectTrigger>
                    <SelectContent>
                      {STRUCTURES.map(st => <SelectItem key={st} value={st}>{t(language, st.toLowerCase().replace(/è/g, "e").replace(/é/g, "e") as any) || st}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                {/* Entry Model */}
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium">{t(language, "entryModelField")}</Label>
                  <Select value={formData.entryModel} onValueChange={(v) => updateField("entryModel", v)}>
                    <SelectTrigger className="w-full h-9"><SelectValue placeholder={language === "fr" ? "Sélectionner" : "Select"} /></SelectTrigger>
                    <SelectContent>
                      {ENTRY_MODELS.map(em => <SelectItem key={em} value={em}>{em}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>

            <Separator />

            {/* ─── Price & Timing ──────────────── */}
            <div className="space-y-4">
              <h4 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">
                {language === "fr" ? "Prix & Timing" : "Price & Timing"}
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium">{t(language, "entryPrice")} *</Label>
                  <Input type="number" step="any" placeholder="0.00" value={formData.entryPrice} onChange={(e) => updateField("entryPrice", e.target.value)} className="h-9 font-mono" />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium">{t(language, "stopLoss")} *</Label>
                  <Input type="number" step="any" placeholder="0.00" value={formData.stopLoss} onChange={(e) => updateField("stopLoss", e.target.value)} className="h-9 font-mono" />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium">{t(language, "takeProfit")} *</Label>
                  <Input type="number" step="any" placeholder="0.00" value={formData.takeProfit} onChange={(e) => updateField("takeProfit", e.target.value)} className="h-9 font-mono" />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium">{t(language, "exitPrice")}</Label>
                  <Input type="number" step="any" placeholder="0.00" value={formData.exitPrice} onChange={(e) => updateField("exitPrice", e.target.value)} className="h-9 font-mono" />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium">{t(language, "lotSize")}</Label>
                  <Input type="number" step="any" placeholder="0.00" value={formData.lotSize} onChange={(e) => updateField("lotSize", e.target.value)} className="h-9 font-mono" />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium">{t(language, "entryTime")}</Label>
                  <Input type="time" value={formData.entryTime} onChange={(e) => updateField("entryTime", e.target.value)} className="h-9 font-mono" />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium">{t(language, "exitTime")}</Label>
                  <Input type="time" value={formData.exitTime} onChange={(e) => updateField("exitTime", e.target.value)} className="h-9 font-mono" />
                </div>
              </div>
            </div>

            <Separator />

            {/* ─── Psychology ──────────────── */}
            <div className="space-y-4">
              <h4 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">
                {language === "fr" ? "Psychologie" : "Psychology"}
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium">{t(language, "emotions")}</Label>
                  <Textarea value={formData.emotions} onChange={(e) => updateField("emotions", e.target.value)} className="min-h-[60px] text-sm" />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium">{t(language, "confluence")}</Label>
                  <Textarea value={formData.confluence} onChange={(e) => updateField("confluence", e.target.value)} className="min-h-[60px] text-sm" />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium">{t(language, "mistakes")}</Label>
                  <Textarea value={formData.mistakes} onChange={(e) => updateField("mistakes", e.target.value)} className="min-h-[60px] text-sm" />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium">{t(language, "lessons")}</Label>
                  <Textarea value={formData.lessons} onChange={(e) => updateField("lessons", e.target.value)} className="min-h-[60px] text-sm" />
                </div>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs font-medium">{t(language, "notes")}</Label>
                <Textarea value={formData.notes} onChange={(e) => updateField("notes", e.target.value)} className="min-h-[60px] text-sm" />
              </div>
            </div>

            <Separator />

            {/* ─── Screenshots & Videos ──────────────── */}
            <div className="space-y-4">
              <h4 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">
                {language === "fr" ? "Captures & Vidéos" : "Screenshots & Videos"}
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                {/* Context Screenshot */}
                <div className="space-y-2">
                  <Label className="text-xs font-medium">{language === "fr" ? "Contexte" : "Context"}</Label>
                  <input ref={contextRef} type="file" accept="image/*,video/*" className="hidden" onChange={(e) => updateField("contextFile", e.target.files?.[0] || null)} />
                  <Button type="button" variant="outline" className="w-full h-9 gap-2" onClick={() => contextRef.current?.click()}>
                    <Upload className="w-3.5 h-3.5" />
                    {formData.contextFile ? formData.contextFile.name.slice(0, 20) : (language === "fr" ? "Choisir" : "Choose")}
                  </Button>
                  {formData.contextFile && (
                    <div className="relative aspect-video rounded-lg overflow-hidden border border-border">
                      {formData.contextFile.type.startsWith('video/') ? (
                        <video src={URL.createObjectURL(formData.contextFile)} className="w-full h-full object-cover" muted playsInline />
                      ) : (
                        <img src={URL.createObjectURL(formData.contextFile)} alt="Context" className="w-full h-full object-cover" />
                      )}
                      <Button variant="ghost" size="icon" className="absolute top-1 right-1 h-6 w-6 bg-background/80" onClick={() => updateField("contextFile", null)}>
                        <X className="w-3 h-3" />
                      </Button>
                    </div>
                  )}
                </div>
                {/* Entry Screenshot */}
                <div className="space-y-2">
                  <Label className="text-xs font-medium">{language === "fr" ? "Entrée" : "Entry"}</Label>
                  <input ref={entryFileRef} type="file" accept="image/*,video/*" className="hidden" onChange={(e) => updateField("entryFile", e.target.files?.[0] || null)} />
                  <Button type="button" variant="outline" className="w-full h-9 gap-2" onClick={() => entryFileRef.current?.click()}>
                    <Upload className="w-3.5 h-3.5" />
                    {formData.entryFile ? formData.entryFile.name.slice(0, 20) : (language === "fr" ? "Choisir" : "Choose")}
                  </Button>
                  {formData.entryFile && (
                    <div className="relative aspect-video rounded-lg overflow-hidden border border-border">
                      {formData.entryFile.type.startsWith('video/') ? (
                        <video src={URL.createObjectURL(formData.entryFile)} className="w-full h-full object-cover" muted playsInline />
                      ) : (
                        <img src={URL.createObjectURL(formData.entryFile)} alt="Entry" className="w-full h-full object-cover" />
                      )}
                      <Button variant="ghost" size="icon" className="absolute top-1 right-1 h-6 w-6 bg-background/80" onClick={() => updateField("entryFile", null)}>
                        <X className="w-3 h-3" />
                      </Button>
                    </div>
                  )}
                </div>
                {/* Exit Screenshot */}
                <div className="space-y-2">
                  <Label className="text-xs font-medium">{language === "fr" ? "Sortie" : "Exit"}</Label>
                  <input ref={exitFileRef} type="file" accept="image/*,video/*" className="hidden" onChange={(e) => updateField("exitFile", e.target.files?.[0] || null)} />
                  <Button type="button" variant="outline" className="w-full h-9 gap-2" onClick={() => exitFileRef.current?.click()}>
                    <Upload className="w-3.5 h-3.5" />
                    {formData.exitFile ? formData.exitFile.name.slice(0, 20) : (language === "fr" ? "Choisir" : "Choose")}
                  </Button>
                  {formData.exitFile && (
                    <div className="relative aspect-video rounded-lg overflow-hidden border border-border">
                      {formData.exitFile.type.startsWith('video/') ? (
                        <video src={URL.createObjectURL(formData.exitFile)} className="w-full h-full object-cover" muted playsInline />
                      ) : (
                        <img src={URL.createObjectURL(formData.exitFile)} alt="Exit" className="w-full h-full object-cover" />
                      )}
                      <Button variant="ghost" size="icon" className="absolute top-1 right-1 h-6 w-6 bg-background/80" onClick={() => updateField("exitFile", null)}>
                        <X className="w-3 h-3" />
                      </Button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-border flex justify-end gap-2 shrink-0">
          <Button variant="outline" onClick={() => onOpenChange(false)}>{t(language, "cancel")}</Button>
          <Button onClick={handleSubmit} disabled={isSubmitting} className="gap-2">
            {isSubmitting ? <Clock className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
            {t(language, "save")}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
